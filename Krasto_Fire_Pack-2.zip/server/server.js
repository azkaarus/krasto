/*
 * Krasto Fire — game + multiplayer relay server
 * © Kanan, Inc
 *
 * Zero dependencies (Node 18+). Implements just enough of RFC 6455 (WebSocket)
 * to relay JSON messages between a room host and its players.
 *
 *   PORT=8080 node server.js                    relay + serves ../public if it exists (all-in-one)
 *   SERVE_STATIC=0 node server.js               relay only (game hosted elsewhere, e.g. Netlify)
 *   ALLOWED_ORIGINS=https://your-site.netlify.app node server.js   (optional, relay only)
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const PORT = +process.env.PORT || 8080;
const ALLOWED = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
const MAX_CLIENTS = +process.env.MAX_CLIENTS || 2000;
const MAX_MSG = 64 * 1024;          // bytes per message
const MAX_RATE = 600;               // messages / second / socket
const ID_RE = /^[A-Za-z0-9_-]{3,40}$/;
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

// ---- optional all-in-one mode: also serve the game (../public) from this server ----
const ROOT = path.resolve(process.env.SERVE_DIR || path.join(__dirname, '..', 'public'));
const SERVE = process.env.SERVE_STATIC !== '0' && fs.existsSync(path.join(ROOT, 'index.html'));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.css': 'text/css; charset=utf-8', '.ico': 'image/x-icon' };
const COMPRESSIBLE = new Set(['.html', '.js', '.json', '.webmanifest', '.svg', '.txt', '.css']);
const gzCache = new Map();

function serveStatic(req, res) {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (_) { res.writeHead(400); return res.end('bad request'); }
  if (p.endsWith('/')) p += 'index.html';
  let file = path.join(ROOT, p);
  if (file !== ROOT && !file.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('forbidden'); }
  let st; try { st = fs.statSync(file); } catch (_) { st = null; }
  let status = 200;
  if (!st || !st.isFile()) {
    file = path.join(ROOT, '404.html'); status = 404;
    try { st = fs.statSync(file); } catch (_) { res.writeHead(404); return res.end('not found'); }
  }
  const ext = path.extname(file).toLowerCase();
  const rel = path.relative(ROOT, file).replace(/\\/g, '/');
  const fresh = ext === '.html' || rel === 'sw.js' || rel === 'config.js' || ext === '.webmanifest';
  const cache = fresh ? 'no-cache' : rel.startsWith('maps/') ? 'public, max-age=86400' : rel.startsWith('icons/') ? 'public, max-age=604800' : 'public, max-age=3600';
  const etag = '"' + st.size.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '"';
  const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache, 'ETag': etag, 'X-Content-Type-Options': 'nosniff', 'Vary': 'Accept-Encoding' };
  if (status === 200 && req.headers['if-none-match'] === etag) { res.writeHead(304, h); return res.end(); }
  const wantGz = COMPRESSIBLE.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  if (req.method === 'HEAD') { res.writeHead(status, h); return res.end(); }
  if (wantGz) {
    let z = gzCache.get(file);
    if (!z || z.etag !== etag) { z = { etag, buf: zlib.gzipSync(fs.readFileSync(file), { level: 6 }) }; gzCache.set(file, z); }
    h['Content-Encoding'] = 'gzip'; h['Content-Length'] = z.buf.length; res.writeHead(status, h); return res.end(z.buf);
  }
  h['Content-Length'] = st.size; res.writeHead(status, h);
  fs.createReadStream(file).pipe(res);
}

const peers = new Map();            // id -> Client
let total = 0;

class Client {
  constructor(sock) {
    this.sock = sock; this.id = null; this.links = new Set();
    this.buf = Buffer.alloc(0); this.frag = []; this.alive = true;
    this.win = Date.now(); this.cnt = 0; this.closed = false;
  }
  sendFrame(op, payload) {
    if (this.closed || this.sock.destroyed) return;
    const len = payload.length; let head;
    if (len < 126) head = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
    try { this.sock.write(Buffer.concat([head, payload])); } catch (_) {}
  }
  send(obj) { this.sendFrame(1, Buffer.from(JSON.stringify(obj))); }
  close(code = 1000) {
    if (this.closed) return; this.closed = true;
    const p = Buffer.alloc(2); p.writeUInt16BE(code);
    try { this.sock.write(Buffer.concat([Buffer.from([0x88, 2]), p])); this.sock.end(); } catch (_) {}
    this.cleanup();
  }
  cleanup() {
    if (this.id && peers.get(this.id) === this) peers.delete(this.id);
    for (const o of this.links) { const c = peers.get(o); if (c) { c.links.delete(this.id); c.send({ t: 'cls', from: this.id }); } }
    this.links.clear();
    if (!this.counted) { this.counted = true; total--; }
  }
  onData(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80);
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const big = b.readBigUInt64BE(2); if (big > BigInt(MAX_MSG)) return this.close(1009); len = Number(big); off = 10; }
      if (len > MAX_MSG) return this.close(1009);
      if (!masked) return this.close(1002);                 // clients must mask
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (op === 8) return this.close();
      if (op === 9) { this.sendFrame(10, data); continue; }
      if (op === 10) { this.alive = true; continue; }
      if (op === 0 || op === 1) {
        this.frag.push(data);
        if (this.frag.reduce((n, x) => n + x.length, 0) > MAX_MSG) return this.close(1009);
        if (fin) { const full = Buffer.concat(this.frag); this.frag = []; this.onText(full.toString('utf8')); }
      }
    }
  }
  onText(s) {
    const now = Date.now();
    if (now - this.win > 1000) { this.win = now; this.cnt = 0; }
    if (++this.cnt > MAX_RATE) return this.close(1008);
    let m; try { m = JSON.parse(s); } catch (_) { return; }
    if (!m || typeof m !== 'object') return;
    switch (m.t) {
      case 'reg': {
        if (this.id) return;
        let id = m.id;
        if (id == null) { do { id = 'p' + crypto.randomBytes(5).toString('hex'); } while (peers.has(id)); }
        else if (typeof id !== 'string' || !ID_RE.test(id)) return this.send({ t: 'err', type: 'invalid-id' });
        if (peers.has(id)) return this.send({ t: 'err', type: 'unavailable-id' });
        this.id = id; peers.set(id, this); this.send({ t: 'reg', id }); break;
      }
      case 'con': {
        if (!this.id || typeof m.to !== 'string') return;
        const o = peers.get(m.to);
        if (!o || o === this) return this.send({ t: 'err', type: 'peer-unavailable', to: m.to });
        this.links.add(o.id); o.links.add(this.id);
        o.send({ t: 'inc', from: this.id }); this.send({ t: 'ok', to: o.id }); break;
      }
      case 'dat': {
        if (!this.id || typeof m.to !== 'string' || !this.links.has(m.to)) return;
        const o = peers.get(m.to); if (o) o.send({ t: 'dat', from: this.id, d: m.d }); break;
      }
      case 'mul': {                       // one message fanned out to several linked peers
        if (!this.id || !Array.isArray(m.to) || m.to.length > 16) return;
        for (const id of m.to) { if (typeof id !== 'string' || !this.links.has(id)) continue; const o = peers.get(id); if (o) o.send({ t: 'dat', from: this.id, d: m.d }); }
        break;
      }
      case 'cls': {
        if (!this.id || !this.links.has(m.to)) return;
        this.links.delete(m.to); const o = peers.get(m.to);
        if (o) { o.links.delete(this.id); o.send({ t: 'cls', from: this.id }); } break;
      }
    }
  }
}

const server = http.createServer((req, res) => {
  const origin = req.headers.origin || '*';
  res.setHeader('Access-Control-Allow-Origin', ALLOWED.length ? (ALLOWED.includes(origin) ? origin : ALLOWED[0]) : '*');
  const url = (req.url || '/').split('?')[0];
  if (url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  if (url === '/status' || !SERVE || (req.method !== 'GET' && req.method !== 'HEAD')) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ name: 'Krasto Fire server', by: 'Kanan, Inc', online: total, rooms: [...peers.keys()].filter(k => k.startsWith('krastofire-')).length, serving_game: SERVE }));
  }
  serveStatic(req, res);
});

server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  const origin = req.headers.origin;
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket' || total >= MAX_CLIENTS ||
      (ALLOWED.length && origin && !ALLOWED.includes(origin))) { sock.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
  const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  sock.setNoDelay(true);
  const c = new Client(sock); total++;
  sock.on('data', d => { try { c.onData(d); } catch (_) { c.close(1011); } });
  sock.on('close', () => { c.closed = true; c.cleanup(); clearInterval(c.timer); });
  sock.on('error', () => { c.closed = true; c.cleanup(); });
  // drop idle clients that never answer pings
  c.timer = setInterval(() => {
    if (c.closed) return clearInterval(c.timer);
    if (!c.alive) { clearInterval(c.timer); return c.close(1001); }
    c.alive = false; c.sendFrame(9, Buffer.alloc(0));
  }, 25000);
});

server.listen(PORT, () => console.log('Krasto Fire server on :' + PORT + (SERVE ? ' (serving game from ' + ROOT + ')' : ' (relay only)')));
