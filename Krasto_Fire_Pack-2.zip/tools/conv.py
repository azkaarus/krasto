import json,base64,io,sys,struct
import numpy as np
from PIL import Image

def load(z):
    g=json.load(open(f'{z}/scene.gltf'))
    buf=open(f'{z}/'+g['buffers'][0]['uri'],'rb').read()
    return g,buf

CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def acc(g,buf,i):
    a=g['accessors'][i];bv=g['bufferViews'][a['bufferView']]
    dt=np.dtype(CT[a['componentType']]);nc=NC[a['type']]
    off=bv.get('byteOffset',0)+a.get('byteOffset',0);st=bv.get('byteStride',0)
    cnt=a['count']
    if st and st!=dt.itemsize*nc:
        raw=np.frombuffer(buf,dtype=np.uint8,count=st*cnt,offset=off).reshape(cnt,st)[:,:dt.itemsize*nc]
        arr=np.ascontiguousarray(raw).view(dt).reshape(cnt,nc)
    else:
        arr=np.frombuffer(buf,dtype=dt,count=cnt*nc,offset=off).reshape(cnt,nc)
    return arr

def nmat(n):
    if 'matrix' in n: return np.array(n['matrix'],dtype=np.float64).reshape(4,4).T
    T=np.eye(4);S=np.eye(4);R=np.eye(4)
    if 'translation' in n: T[:3,3]=n['translation']
    if 'scale' in n: S[0,0],S[1,1],S[2,2]=n['scale']
    if 'rotation' in n:
        x,y,z,w=n['rotation'];R[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]
    return T@R@S

def flatten(z):
    """returns list of dict(mat=idx,P,UV,I)"""
    g,buf=load(z);out=[]
    def walk(ni,M):
        n=g['nodes'][ni];M2=M@nmat(n)
        if 'mesh' in n:
            for p in g['meshes'][n['mesh']]['primitives']:
                if p.get('mode',4)!=4: continue
                P=acc(g,buf,p['attributes']['POSITION']).astype(np.float64)
                P=(np.c_[P,np.ones(len(P))]@M2.T)[:,:3]
                uv=acc(g,buf,p['attributes']['TEXCOORD_0']).astype(np.float64) if 'TEXCOORD_0' in p['attributes'] else np.zeros((len(P),2))
                I=acc(g,buf,p['indices']).reshape(-1).astype(np.int64) if 'indices' in p else np.arange(len(P))
                # flip winding if det<0
                if np.linalg.det(M2[:3,:3])<0:
                    I=I.reshape(-1,3)[:,[0,2,1]].reshape(-1)
                out.append(dict(mat=p.get('material',0),P=P,UV=uv,I=I))
        for c in n.get('children',[]): walk(c,M2)
    for r in g['scenes'][g.get('scene',0)]['nodes']: walk(r,np.eye(4))
    return g,out

def mat_info(g,i,z,maxtex,fmt_png_small=True):
    m=g['materials'][i];pb=m.get('pbrMetallicRoughness',{})
    c=pb.get('baseColorFactor',[1,1,1,1])
    t=None
    if 'baseColorTexture' in pb:
        t=g['images'][g['textures'][pb['baseColorTexture']['index']]['source']]['uri']
    return c,t,m.get('alphaMode','OPAQUE')

def texuri(z,uri,maxtex,q=88):
    im=Image.open(f'{z}/{uri}');pal=(im.mode=='P')
    hasa=im.mode in('RGBA','LA','P') and ('A' in im.getbands() or im.mode=='P')
    w,h=im.size
    if max(w,h)>maxtex:
        s=maxtex/max(w,h);im=im.resize((max(1,int(w*s)),max(1,int(h*s))),Image.LANCZOS)
    b=io.BytesIO()
    if hasa and im.mode!='RGB':
        im=im.convert('RGBA');a=np.array(im)[:,:,3]
        if a.min()<250 or pal: im.save(b,'PNG',optimize=True);mime='png'
        else: im.convert('RGB').save(b,'JPEG',quality=q);mime='jpeg'
    else:
        if max(w,h)<=64: im.convert('RGB').save(b,'PNG',optimize=True);mime='png'
        else: im.convert('RGB').save(b,'JPEG',quality=q);mime='jpeg'
    return 'data:image/%s;base64,'%mime+base64.b64encode(b.getvalue()).decode(), im.size, mime

def build(z,scale_to,maxtex,center=True,ground_y=None,rot=None,extra_fn=None,merge=True,drop=None):
    g,prims=flatten(z)
    allP=np.concatenate([p['P'] for p in prims])
    if rot is not None:
        for p in prims: p['P']=p['P']@rot.T
        allP=np.concatenate([p['P'] for p in prims])
    mn=allP.min(0);mx=allP.max(0);ext=mx-mn
    print(z,'raw bounds',mn,mx,'ext',ext)
    s=scale_to/max(ext[0],ext[2])
    cx=(mn[0]+mx[0])/2;cz=(mn[2]+mx[2])/2
    for p in prims:
        p['P']=(p['P']-np.array([cx,mn[1],cz]))*s
    allP=np.concatenate([p['P'] for p in prims]);mn=allP.min(0);mx=allP.max(0)
    return g,prims,s,mn,mx
