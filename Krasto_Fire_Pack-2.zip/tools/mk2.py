import sys,json,os;sys.path.insert(0,'.')
from run_helpers import *
def decimate(prims,target):
    P=np.concatenate([p['P'] for p in prims]);UV=np.concatenate([p['UV'] for p in prims])
    off=0;I=[]
    for p in prims: I.append(p['I']+off);off+=len(p['P'])
    I=np.concatenate(I).reshape(-1,3)
    ext=(P.max(0)-P.min(0)).max()
    lo,hi=ext/2000,ext/20
    for _ in range(14):
        cs=(lo*hi)**.5
        k=np.c_[np.floor(P/cs),np.floor(UV*200)].astype(np.int64)
        u,inv=np.unique(k,axis=0,return_inverse=True);inv=inv.reshape(-1)
        t=inv[I];ok=(t[:,0]!=t[:,1])&(t[:,1]!=t[:,2])&(t[:,0]!=t[:,2])
        n=ok.sum()
        if n>target: lo=cs
        else: hi=cs
    cnt=np.bincount(inv,minlength=len(u))[:,None]
    nP=np.zeros((len(u),3));nU=np.zeros((len(u),2))
    np.add.at(nP,inv,P);np.add.at(nU,inv,UV);nP/=cnt;nU/=cnt
    t=inv[I][ok]
    return [dict(mat=prims[0]['mat'],P=nP,UV=nU,I=t.reshape(-1))],cs
def prop(z,sc,maxtex,dec=None):
    g,prims=flatten(z)
    if dec: prims,cs=decimate(prims,dec);print(z,'decimated cs',cs)
    A=np.concatenate([p['P'] for p in prims]);mn=A.min(0);mx=A.max(0)
    c=np.array([(mn[0]+mx[0])/2,mn[1],(mn[2]+mx[2])/2])
    for p in prims:p['P']=(p['P']-c)*sc
    texmap={};texlist=[];groups=[]
    add_prims(prims,g,z,None,None,None,texmap,texlist,maxtex,groups)
    print(z,'groups',len(groups),'tris',sum(len(x['I']) for x in groups)//3)
    e=emit(groups,texlist);print(' ex',[round(x,1) for x in e['ex']]);return e
res={}
res['RMN']=prop('ichiraku_ramen_-_naruto',1.1,512)
res['MAL']=prop('malevolent_shrine__jujutsu_kaisen',2.2,1024)
res['SHR']=prop('japanese_shrine_-_traditional_temple',9.0,2048,dec=170000)
open('../public/maps/props.js','w').write('AS.PROPS='+json.dumps(res,separators=(',',':'))+';')
print('props MB',os.path.getsize('../public/maps/props.js')/1e6)
# ---- Hidden Leaf map
g,prims=flatten('naruto_hiddenly_village')
A=np.concatenate([p['P'] for p in prims]);mn=A.min(0);mx=A.max(0)
S=300.0/max(mx[0]-mn[0],mx[2]-mn[2]);c=np.array([(mn[0]+mx[0])/2,mn[1],(mn[2]+mx[2])/2])
for p in prims:p['P']=(p['P']-c)*S
A=np.concatenate([p['P'] for p in prims]);print('HID scale',S,'bounds',A.min(0).round(1),A.max(0).round(1))
nrm=[];
for p in prims:
    t=p['I'].reshape(-1,3);a,b,cc=p['P'][t[:,0]],p['P'][t[:,1]],p['P'][t[:,2]];n=np.cross(b-a,cc-a);ar=np.linalg.norm(n,axis=1)
    nrm.append((n[:,1]/np.maximum(ar,1e-9)*ar).sum()/ar.sum())
print('up-area frac',nrm)
texmap={};texlist=[];groups=[]
add_prims(prims,g,'naruto_hiddenly_village',None,40.0,None,texmap,texlist,2048,groups)
R=215
Pq,UV,I=quad(-R,R,-R,R,-0.05);
if up_tri(Pq,I)[0]<0:I=np.array([0,1,2,0,2,3])
groups.append(dict(P=Pq,UV=UV,I=I,color=[0.42,0.62,0.30],tex=None,alpha=False))
e=emit(groups,texlist);print('HID tris',sum(len(x['I']) for x in groups)//3,e['mn'],e['ex'])
open('../public/maps/hid.js','w').write('AS.HID='+json.dumps(e,separators=(',',':'))+';')
print('hid MB',os.path.getsize('../public/maps/hid.js')/1e6)
