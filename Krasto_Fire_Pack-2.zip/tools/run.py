import sys,json;sys.path.insert(0,'.')
from build import *
res={}
# ---------- PERSIAN CITY ----------
g,prims=flatten('persian_city')
s=0.075;cx,cz=800.0,-450.0
for p in prims: p['P']=(p['P']-np.array([cx,-6.0,cz]))*s
texmap={};texlist=[];groups=[]
add_prims(prims,g,'persian_city',None,50.0,215.0,texmap,texlist,2048,groups,skipmat=(8,))
# custom ground (desert aerial texture, tiled) so the map edge is clean
uri='textures/dubai_desert_aerial_view_3230306_baseColor.jpeg'
d,sz,mime=texuri('persian_city',uri,2048);gi=len(texlist);texlist.append(d)
R=260
P,UV,I=quad(-R,R,-R,R,-0.02,uvs=14.0)
if up_tri(P,I)[0]<0: I=np.array([0,1,2,0,2,3])
groups.append(dict(P=P,UV=UV,I=I,color=[1,1,1],tex=gi,alpha=False))
tv=sum(len(x['P']) for x in groups);tt=sum(len(x['I']) for x in groups)//3
print('PERS groups',len(groups),'verts',tv,'tris',tt)
res['PERS']=emit(groups,texlist);print('PERS json MB',len(json.dumps(res['PERS']))/1e6,'mn',res['PERS']['mn'],'ex',res['PERS']['ex'])
# ---------- INDUSTRIAL ----------
g,prims=flatten('low_poly_industrial_zone')
cx,cz=13.5,-8.0
for p in prims: p['P']=p['P']-np.array([cx,0,cz])
texmap={};texlist=[];groups=[]
add_prims(prims,g,'low_poly_industrial_zone',None,32.0,None,texmap,texlist,1024,groups,skipmat=(6,))
print('IND groups',len(groups),'verts',sum(len(x['P']) for x in groups),'tris',sum(len(x['I']) for x in groups)//3)
res['IND']=emit(groups,texlist);print('IND json MB',len(json.dumps(res['IND']))/1e6,res['IND']['mn'],res['IND']['ex'])
# ---------- STAIR KEEP ----------
g,prims=flatten('medieval_stairs')
SC=1.4
texmap={};texlist=[];groups=[]
# stairs texture (2048 jpeg) + average colour for platforms
uri='textures/Stairs_baseColor.png'
d,sz,mime=texuri('medieval_stairs',uri,2048,q=90);texlist.append(d);print(' stairs tex',sz,len(d)//1024,'KB')
im=Image.open('medieval_stairs/'+uri).convert('RGB').resize((64,64));avg=(np.array(im).reshape(-1,3).mean(0)/255.0)
print(' avg colour',avg)
base=[]
for p in prims:
    P=p['P'].copy();P[:,1]-=0.23   # tread base -> ground
    P[:,0]-=4.06;P[:,2]+=2.08      # top edge centre -> origin, climb dir +x
    base.append((P*SC,p['UV'],p['I']))
def flight(rot,tx,ty,tz):
    c,sn=math.cos(rot),math.sin(rot)
    for P,UV,I in base:
        X=P[:,0]*c+P[:,2]*sn;Z=-P[:,0]*sn+P[:,2]*c
        Q=np.stack([X+tx,P[:,1]+ty,Z+tz],1)
        groups.append(dict(P=Q,UV=UV,I=I,color=[1,1,1],tex=0,alpha=False))
H=SC*4.01          # tier height
T1=22.0;T2=9.0     # half sizes of tiers
col=list(avg*0.9)
def plat(x0,x1,y0,y1,z0,z1):
    P,UV,I=box(x0,x1,y0,y1,z0,z1);groups.append(dict(P=P,UV=UV,I=I,color=col,tex=None,alpha=False))
# ground
P,UV,I=quad(-110,110,-110,110,0.0);
if up_tri(P,I)[0]<0: I=np.array([0,1,2,0,2,3])
groups.append(dict(P=P,UV=UV,I=I,color=[0.36,0.34,0.30],tex=None,alpha=False))
plat(-T1,T1,0,H,-T1,T1)                  # tier 1
plat(-T2,T2,H,2*H,-T2,T2)                # tier 2
# 4 flights up tier 1 (top edge at platform edge, climbing toward centre)
for k in range(4):
    a=k*math.pi/2;dx,dz=math.cos(a),math.sin(a)
    # climb direction points toward centre => rotation so local +x = -(dx,dz)
    rot=math.atan2(dz,-dx)  # local +x -> (-dx,-dz)
    flight(rot,dx*T1,0,dz*T1)
    flight(rot,dx*T2,H,dz*T2)
# corner ramps of stairs on the ground leading to nothing (cover / sniper perches)
for sx in(-1,1):
    for sz_ in(-1,1):
        plat(sx*62-4,sx*62+4,0,H,sz_*62-4,sz_*62+4)
        flight(0.0 if sx>0 else math.pi,sx*58,0,sz_*62)
res['STR']=emit(groups,texlist);print('STR groups',len(groups),'json MB',len(json.dumps(res['STR']))/1e6,res['STR']['mn'],res['STR']['ex'])
json.dump(res,open('maps.json','w'),separators=(',',':'))
import os;print('maps.json MB',os.path.getsize('maps.json')/1e6)
