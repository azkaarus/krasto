import sys,json,base64,math
sys.path.insert(0,'.')
from conv import *

def b64(a): return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()

def emit(groups,texlist):
    """groups: list of dict(P,UV,I,color,tex,alpha) -> AS entry"""
    allP=np.concatenate([g['P'] for g in groups]);mn=allP.min(0);mx=allP.max(0);ex=np.maximum(mx-mn,1e-4)
    out=[]
    for g in groups:
        P=g['P'];UV=g['UV'];I=g['I']
        qp=np.clip(np.round((P-mn)/ex*65535),0,65535).astype(np.uint16)
        um=UV.min(0);ue=np.maximum(UV.max(0)-um,1e-6)
        qu=np.clip(np.round((UV-um)/ue*65535),0,65535).astype(np.uint16)
        w=1 if len(P)>65535 else 0
        Ii=I.astype(np.uint32 if w else np.uint16)
        d={'p':b64(qp),'u':b64(qu),'i':b64(Ii),'w':w,'n':len(P),'um':[float(x) for x in um],'ue':[float(x) for x in ue],'c':[float(x) for x in g['color'][:3]],'a':1 if g.get('alpha') else 0}
        d['t']=g['tex']  # may be None
        out.append(d)
    return {'mn':[float(x) for x in mn],'ex':[float(x) for x in ex],'g':out,'t':texlist}

def split(P,UV,I,cellkey):
    """split triangles by cell key function on centroid -> list of (P,UV,I) with compacted verts"""
    tri=I.reshape(-1,3);cen=(P[tri[:,0]]+P[tri[:,1]]+P[tri[:,2]])/3
    keys=cellkey(cen)
    res=[]
    for k in np.unique(keys,axis=0):
        sel=np.all(keys==k,axis=1) if keys.ndim>1 else keys==k
        t=tri[sel]
        u,inv=np.unique(t.reshape(-1),return_inverse=True)
        res.append((P[u],UV[u],inv.astype(np.int64)))
    return res

def add_prims(prims,g,z,keep,cell,crop,texmap,texlist,maxtex,groups,skipmat=()):
    for mi in sorted(set(p['mat'] for p in prims)):
        if mi in skipmat: continue
        ps=[p for p in prims if p['mat']==mi]
        P=[];UV=[];I=[];off=0
        for p in ps:
            P.append(p['P']);UV.append(p['UV']);I.append(p['I']+off);off+=len(p['P'])
        P=np.concatenate(P);UV=np.concatenate(UV);I=np.concatenate(I)
        tri=I.reshape(-1,3);cen=(P[tri[:,0]]+P[tri[:,1]]+P[tri[:,2]])/3
        ok=np.ones(len(tri),bool)
        if crop is not None:
            ok&=(np.abs(cen[:,0])<crop)&(np.abs(cen[:,2])<crop)
        # drop degenerate triangles
        a,b,c=P[tri[:,0]],P[tri[:,1]],P[tri[:,2]]
        ok&=np.linalg.norm(np.cross(b-a,c-a),axis=1)>1e-9
        tri=tri[ok]
        if len(tri)==0: continue
        col,uri,mode=mat_info(g,mi,z,0)
        if uri is not None:
            if uri not in texmap:
                d,sz,mime=texuri(z,uri,maxtex);texmap[uri]=len(texlist);texlist.append(d);print('  tex',uri.split('/')[-1],sz,mime,len(d)//1024,'KB')
            ti=texmap[uri]
        else: ti=None
        col=col[:3]
        for (pp,uu,ii) in split(P,UV,tri.reshape(-1),lambda c:(np.floor(c[:,0]/cell).astype(int)*1000+np.floor(c[:,2]/cell).astype(int)) if cell else np.zeros(len(c),int)):
            groups.append(dict(P=pp,UV=uu,I=ii,color=col if ti is None else [1,1,1],tex=ti,alpha=(mode=='MASK')))

def quad(x0,x1,z0,z1,y,uvs=1.0):
    P=np.array([[x0,y,z0],[x1,y,z0],[x1,y,z1],[x0,y,z1]],float)
    UV=np.array([[0,0],[uvs,0],[uvs,uvs],[0,uvs]],float)
    return P,UV,np.array([0,2,1,0,3,2])  # check normal below

def up_tri(P,I):
    tri=I.reshape(-1,3);a,b,c=P[tri[:,0]],P[tri[:,1]],P[tri[:,2]];n=np.cross(b-a,c-a)
    return n[:,1]

def box(x0,x1,y0,y1,z0,z1):
    V=np.array([[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]],float)
    faces=[([4,5,6,7],(0,1,0)),([0,1,2,3],(0,-1,0)),([0,1,5,4],(0,0,-1)),([3,2,6,7],(0,0,1)),([0,3,7,4],(-1,0,0)),([1,2,6,5],(1,0,0))]
    P=[];I=[];UV=[];off=0
    for q,nv in faces:
        pts=V[q];P.append(pts);UV.append(np.array([[0,0],[1,0],[1,1],[0,1]],float)*np.array([1,1]))
        t=[[0,1,2],[0,2,3]]
        for tt in t:
            a,b,c=pts[tt[0]],pts[tt[1]],pts[tt[2]]
            if np.dot(np.cross(b-a,c-a),nv)<0: tt=[tt[0],tt[2],tt[1]]
            I+= [off+k for k in tt]
        off+=4
    return np.concatenate(P),np.concatenate(UV),np.array(I)
