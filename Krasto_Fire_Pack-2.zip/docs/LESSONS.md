# Lessons — how Krasto Fire works
© Kanan, Inc

Short lessons for anyone learning from, or extending, the game. The game script lives in `public/index.html`; big maps are separate files in `public/maps/`.

## Lesson 1 — Layers
1. **index.html**: the game script, the UI, characters/weapons data and the default maps.
2. **maps/*.js**: large map meshes. Each file does `AS.NAME = {...}` and is downloaded the first time that map is picked (`ensureMap` / `withMap`).
3. **config.js**: online settings, edited without touching the game.
4. **sw.js + manifest.webmanifest**: make it installable and playable offline after the first visit.

## Lesson 2 — Adding a map entry
Maps are objects in the `MAPS` array. Fields for mesh maps:
`n` name · `d` description · `mesh` key in `AS` (matches `maps/<key>.js`) · `cs` collision cell size (smaller = finer steps, more memory) · `zr` safe-zone radius · `lim` hard boundary · `vd` fall-death height · `sy0` lowest allowed spawn height · `sz` size factor (more bots/loot) · `orb`/`oh`/`ly` lobby preview camera · `ns` don't cast shadows (speed) · `tag` badge on the lobby card.

## Lesson 3 — From 3D model to map
`tools/` holds the scripts used for the Sketchfab models:
1. Read the glTF and bake every node transform into the vertices.
2. Scale and re-center so the play area is around (0,0) with the ground near y = 0.
3. Split triangles into spatial cells so off-screen chunks are skipped by the camera.
4. Quantize positions and UVs to 16-bit integers (about 10 bytes per vertex), base64 them, and store the bounding box so the game can decode them.
5. Recompress textures (JPEG, or PNG when palettes/transparency need it).
At load the game builds a **collision grid** (walkable floors = upward-facing triangles, walls = steep ones). Players step up `STEP = 0.62` m, so staircase risers must stay below that.

## Lesson 4 — Bot brain
Each bot runs `botBrain` every frame: line-of-sight raycasts (a few per frame, shared), hearing your shots, a memory of where it last saw you, burst fire, strafing, retreat at low health, flanking on Hard. Tuning knobs: the `DIF` table and constants at the top of `botBrain`.

## Lesson 5 — Team matches
`TM` is the match state: scores, round number and a small state machine `ready → live → wait`. `tmRound` hands out fresh loadouts and spawns; `tmStep` decides when a round or match ends. In Clash Squad `tmTarget` gives each bot its nearest enemy — a bot or you.

## Lesson 6 — Online play
- One player is the **host** and referees. Everyone sends their position ~12×/second; the host relays, and each client shows others as "avatar" bots.
- **Hits are shooter-authoritative**: your game decides it hit, then sends the damage to the victim's game. Snappy and simple, but trusting.
- The host decides round winners and sends spawn positions so everyone starts together.
- Always escape player names before putting them in HTML (`esc()`).

## Lesson 7 — Transports
The game talks to one tiny interface (`peer.on`, `connect`, `send`). Two things implement it: the PeerJS cloud (peer-to-peer) and `WSPeer`, which talks to `server/server.js`. The server only forwards between peers that linked, caps message size and rate, and pings idle sockets. `mul` lets the host send one message that the server fans out to everyone — important for 4v4, where the host would otherwise send hundreds of messages a second.

## Lesson 8 — Graphics tiers & atmosphere
`gq` is 0 Low / 1 High / 2 Ultra. `applyGQ` sets pixel ratio, shadow-map size and (via `AN()`) texture sharpness; Ultra also lets the big city cast shadows. `ambSetup/ambTick` draw one `THREE.Points` cloud of dust/ash around the camera, configured per map with the `amb` field of its `MAPS` entry.

## Lesson 9 — Loadouts
In Clash Squad `tmRound` opens a 7-second loadout phase: `ldPick(i)` gives pistol + melee + the chosen primary with full ammo. Loadouts are local — hits are decided by the shooter — so nothing extra has to be synced online.

## Lesson 10 — Shipping
Static hosts serve `public/`. Cache rules: HTML/config/service worker are always revalidated; maps and icons are cached. Bump `VERSION` (sw.js) and `KF_VER` (config.js) on every release.

## Ideas to build next
Public room list · server-side hit checks · ping markers · more Clash Squad weapons · per-player stats on a server · cosmetic store (see the launch checklist first).
