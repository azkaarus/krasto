# Credits

**Game:** Krasto Fire — © Kanan, Inc

## Maps (3D models, via Sketchfab, licensed CC BY 4.0)
CC BY 4.0 allows commercial use **as long as you keep these credits** wherever the game is shared. The same text ships as `public/credits.txt`, linked from the game footer. Keep that file published with the game.

- This work is based on "Low Poly Industrial Zone" (https://sketchfab.com/3d-models/low-poly-industrial-zone-17816ea520cc40db9b094ec7779d2757) by novikto (https://sketchfab.com/novikto) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
- This work is based on "Persian City" (https://sketchfab.com/3d-models/persian-city-0147294fccfa461db6eb7c5ac80fd6ff) by farhad.Guli (https://sketchfab.com/farhad.Guli) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
- This work is based on "Medieval Stairs" (https://sketchfab.com/3d-models/medieval-stairs-48e99c4d603b49caa4d9a0cdd8d2774b) by Rudi (https://sketchfab.com/Rudiholder) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)

Changes made: models were rescaled, re-centered, cropped to the play area, split into chunks, and their textures recompressed. "Stair Keep" is a new level built from copies of the Medieval Stairs model plus added platforms.

## Libraries (loaded from CDNs)
- three.js r128 — MIT
- PeerJS 1.5.4 — MIT (only used in peer-to-peer mode)

## Other assets
Characters, weapons, sounds and effects in the base game are part of Kanan, Inc's original Krasto Fire 1.0 file. Confirm you hold the rights to every asset in it before a commercial release.

## Anime Edition models

ANIME EDITION MODELS
- This work is based on "Naruto hiddenly village" (https://sketchfab.com/3d-models/naruto-hiddenly-village-bd95c17d67c44756b4fa5097bce9a547) by kyrox (https://sketchfab.com/kyroxffx) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
- This work is based on "Ichiraku Ramen - Naruto" (https://sketchfab.com/3d-models/ichiraku-ramen-naruto-8a5953bdd4b64b089ef0e08ad15ce368) by benjaminshaw (https://sketchfab.com/benjaminshaw) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
- This work is based on "Japanese Shrine - Traditional Temple" (https://sketchfab.com/3d-models/japanese-shrine-traditional-temple-976033be8d5e415da0709291375da4f1) by aumiella (https://sketchfab.com/aumiella) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
- This work is based on "Malevolent Shrine - Jujutsu Kaisen" (https://sketchfab.com/3d-models/malevolent-shrine-jujutsu-kaisen-b0e9e4a8682c43acaf9051c507c2b13b) by TSK_VITANK (https://sketchfab.com/TSK_VITANK) licensed under CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0/) -- NON-COMMERCIAL ONLY
Changes made: models were rescaled, re-centered, simplified (the Japanese Shrine was reduced from 1.4M to 170k triangles), and their textures recompressed.

**Licence warning:** "Malevolent Shrine" is CC BY-NC (no commercial use). Remove it from `public/maps/props.js` (key `MAL`) before any commercial launch.
