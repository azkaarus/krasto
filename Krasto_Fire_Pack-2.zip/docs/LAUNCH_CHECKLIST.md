# Launch checklist — Krasto Fire
© Kanan, Inc

This is a practical checklist, not legal advice.

## Before you publish
- [ ] **Contact details:** set `contact` in `public/config.js` (email or web page). It appears on the Privacy and Terms pages.
- [ ] **Legal pages:** read `public/privacy.html` and `public/terms.html`, and have a lawyer review them for the countries you will sell or advertise in. They describe what the game does today (local storage, no accounts, no analytics, peer-to-peer or relay online play). **If you add ads, analytics, accounts or payments, update both pages first.**
- [ ] **Assets:** the three new maps are CC BY 4.0 (commercial use allowed with credit). Confirm you also own or license everything in the original game file: characters, weapons, sounds, music, fonts.
- [ ] **Credits file stays published:** `public/credits.txt` (linked as “Credits” in the footer). CC BY 4.0 requires attribution to travel with the game; don't delete the file or the link.
- [ ] **Domain + HTTPS:** attach your own domain in the host's dashboard. All hosts listed give free HTTPS.
- [ ] **Test on real devices:** one low-end Android phone, one iPhone, one PC browser. Try Persian City last (heaviest).
- [ ] **Two-device online test** in the Online tab.
- [ ] **Version bump** (`sw.js` VERSION + `config.js` KF_VER) with every release.

## Nice to have
- Add your own store/website links and a support email to the lobby footer.
- Put `icons/og-image.png` (already included) into social posts — it is the link preview image.
- Install test: Chrome/Edge → Install app; iPhone Safari → Share → Add to Home Screen.
- Uptime monitor on `/health` if you run the game server.

## If you want app-store listings later
The game is already a Progressive Web App (manifest + service worker). It can be wrapped for Google Play (Trusted Web Activity) or the App Store (Capacitor) with the same files. Store rules about shooters, age ratings and online play are your responsibility.

## Growing the multiplayer
The included relay and shooter-authoritative hits are fine for friends and small communities. For a large public audience add: server-side hit checks, matchmaking, reports/moderation and anti-cheat.
