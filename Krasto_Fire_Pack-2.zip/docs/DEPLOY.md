# Deploying Krasto Fire
© Kanan, Inc

The game is a static website in `public/`. Online rooms work peer-to-peer everywhere. An optional server adds a dedicated multiplayer relay.

---
## 1. Static hosts (game only)

### Netlify
- **Fastest:** open https://app.netlify.com/drop and drag the **`public`** folder in.
- **From Git:** Add new site → Import from Git → pick the repo. `netlify.toml` sets the publish folder to `public`; no build command.

### Vercel
Import the repo. `vercel.json` sets the output folder to `public`. Framework preset: *Other*. No build command.

### Cloudflare Pages
Create a project from the repo (or upload `public`). Build command: *none*. Build output directory: `public`.
Cloudflare Pages rejects single files over **25 MiB**. The biggest file here is `maps/pers.js` (about 21.5 MiB). Keep any map you add under 25 MiB (lower texture size or crop the model).

### GitHub Pages
Push to GitHub, then Settings → Pages → Source: **GitHub Actions**. The included workflow (`.github/workflows/pages.yml`) publishes `public/` on every push to `main`.

### Firebase Hosting
`firebase init hosting` (use existing `firebase.json`, public directory `public`), then `firebase deploy`.

All of these serve over HTTPS and compress text automatically (the 8 MB game page downloads at about 3 MB).

---
## 2. All-in-one hosts (game + your own multiplayer server)
Static hosts cannot keep WebSocket connections open, so the server needs a Node-capable host. One service can serve **both** the game and the multiplayer relay:

### Render
New → Blueprint → select the repo (reads `render.yaml`). When it is live, open `public/config.js` and set:
```js
window.KF_CONFIG = { relay: 'auto', contact: 'support@yourdomain.com' };
```
Redeploy. The Online tab shows *Connection: game server*. (Free Render services sleep when idle, so the first visit after a pause can take up to a minute.)

### Railway, Fly.io, Cloud Run, any VPS
Use the `Dockerfile` (or `npm start`, or the `Procfile`). The server listens on `$PORT` (default 8080). Put HTTPS in front — most platforms do it for you — then set `relay: 'auto'` as above.

### Relay on a server, game on a static host
Deploy the game to Netlify/Vercel/etc. as in section 1, and run **only** the relay somewhere else:
```
cd server && SERVE_STATIC=0 node server.js        # or build server/Dockerfile
```
Then in `public/config.js`:
```js
window.KF_CONFIG = { relay: 'wss://your-relay.example.com', contact: '' };
```
Optionally lock it to your site: `ALLOWED_ORIGINS=https://your-site.netlify.app`.
The address must start with `wss://` when your site is HTTPS.

---
## 3. Releasing an update
1. Change `VERSION` in `public/sw.js` and `KF_VER` in `public/config.js` (for example `1.0.1`). This makes installed copies and cached maps refresh.
2. Redeploy.

## 4. Checking it works
1. Open the site on two devices (or two tabs).
2. Online tab → create a room on one, join with the code on the other.
3. Host presses START MATCH when everyone is ready.
Server health check: `https://your-server/health` should say `ok`; `/status` shows players and rooms.

## Troubleshooting
- **Room not found** — wrong code, or the host left.
- **Stuck on Connecting** — some school/office networks block peer-to-peer. Use the game server (section 2).
- **Works locally but not online** — relay address must be `wss://`, not `ws://`.
- **A map won't load** — check that `public/maps/*.js` was deployed and not blocked by a size limit.
- **Old version still shows** — you forgot step 3.1, or the browser has the old service worker; hard-refresh once.
