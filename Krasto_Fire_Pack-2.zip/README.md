# KRASTO FIRE
**by Kanan, Inc**

A free 3D shooter that runs in the browser — phone, tablet or PC, nothing to install. Battle royale vs bots, Clash Squad team matches (1v1 · 2v2 · 3v3 · 4v4) with a weapon pick every round, and online rooms with friends. It can also be installed to the home screen like an app and starts offline after the first visit.

**What's new in 1.1**
- **Ultra graphics** (Lobby → graphics): sharper shadows, maximum texture sharpness, shadows on the big city — the heaviest setting, for strong devices.
- **Atmosphere:** drifting dust and ash on Persian City, Industrial Zone and Stair Keep.
- **Loadout phase:** every Clash Squad round starts with a 7-second primary-weapon pick (SMG · Rifle · Shotgun · Sniper).
- Third-party attribution now lives in `public/credits.txt` (linked from the footer) instead of on the game screens.

## Host it anywhere
It is a plain static website (the `public/` folder). Pick any host:

| Host | How | Notes |
|---|---|---|
| **Netlify** | drag `public/` to app.netlify.com/drop | or connect the repo — `netlify.toml` is included |
| **Vercel** | import the repo | `vercel.json` included |
| **Cloudflare Pages** | build output directory: `public`, no build command | every file is under its 25 MiB limit |
| **GitHub Pages** | push to GitHub, Settings → Pages → *GitHub Actions* | workflow included |
| **Firebase Hosting** | `firebase deploy` | `firebase.json` included |
| **Render / Railway / Fly.io / VPS / Docker** | all-in-one: serves the game **and** the multiplayer server | `render.yaml`, `Dockerfile`, `Procfile` included |

Full steps: `docs/DEPLOY.md`.

## Online play
- **Works out of the box** on every host above, peer-to-peer (friends only need the 4-letter room code).
- **Want your own game server?** The included relay needs no dependencies (`node server/server.js`). Static hosts can't run it, so use the all-in-one hosts above, or run the relay on one of them and point `public/config.js` at it. Details in `docs/DEPLOY.md`.

## What is in the box
```
public/      the website: index.html, maps/ (loaded on demand), icons/, config.js,
             manifest + service worker (installable, offline), privacy.html, terms.html
server/      zero-dependency Node server: multiplayer relay + optional static hosting
docs/        DEPLOY.md · LAUNCH_CHECKLIST.md · LESSONS.md · CREDITS.md
tools/       the scripts that turned .glb/.gltf models into game maps
netlify.toml · vercel.json · firebase.json · render.yaml · Dockerfile · Procfile · .github/
```

## Quick local test
```
npm start        # http://localhost:8080  (game + multiplayer server)
```
(needs Node 18+; there is nothing to install)

## Controls
Touch: virtual stick to move, buttons for fire, jump, reload and more; tap the weapon slots to switch.
Keyboard: WASD move · Space jump · mouse aim · LMB fire · RMB scope · R reload · C sit · Z prone · Shift/Q run · F car · G hero power.

## Legal
© Kanan, Inc. Three maps are built from third-party CC BY 4.0 models; their attribution is in `public/credits.txt` (linked as “Credits” in the game footer) and `docs/CREDITS.md`. Keep that file with the game — the licence requires it. The Privacy and Terms pages are plain-language starting points; have them reviewed before a commercial launch (`docs/LAUNCH_CHECKLIST.md`).
