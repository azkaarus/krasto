/*
 * Krasto Fire — settings you can change without touching the game file.
 * © Kanan, Inc
 *
 * relay:   ''      peer-to-peer online rooms (works on every static host)
 *          'auto'  use the game server on this same website (all-in-one hosting)
 *          'wss://your-server.example.com'   a separate relay server
 * contact: shown on the Privacy and Terms pages (an email address or a web page)
 */
window.KF_CONFIG = { relay: '', contact: '' };
window.KF_VER = '1.3.0';   // bump together with VERSION in sw.js to refresh cached maps
