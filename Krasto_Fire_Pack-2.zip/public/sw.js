/* Krasto Fire service worker — Kanan, Inc
 * Makes the game installable and lets it start offline after the first visit.
 * Bump VERSION whenever you publish a new build so players get fresh files. */
const VERSION = 'kf-1.3.0';
const CORE = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'credits.txt'];
const CDN = /(^|\.)cdnjs\.cloudflare\.com$|(^|\.)cdn\.jsdelivr\.net$/;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== location.origin && !CDN.test(u.hostname)) return;   // never touch other traffic
  if (u.origin === location.origin && u.pathname.endsWith('/config.js')) return; // always fresh
  e.respondWith(caches.open(VERSION).then(async cache => {
    const hit = await cache.match(r);
    const net = fetch(r).then(res => {
      if (res && (res.status === 200 || res.type === 'opaque')) cache.put(r, res.clone()).catch(() => {});
      return res;
    }).catch(() => hit);
    return hit || net;                                                // stale-while-revalidate
  }));
});
